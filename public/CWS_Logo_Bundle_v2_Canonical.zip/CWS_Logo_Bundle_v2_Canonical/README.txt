CONSULT WHITESPACE LLC — LOGO BUNDLE
Prepared by HyperBrand Creative
hyperbrand.ai

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

FOLDER STRUCTURE

  01_AI  — Editable Adobe Illustrator source files
  02_SVG — Scalable Vector Graphics (web, digital use)
  03_PNG — Transparent PNG (presentations, documents, email)
  04_PDF — Print-ready PDF (all 15 treatments, one file)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

LOGO TREATMENTS (15 TOTAL)

  STACKED LOCKUP
  01 — Full Color / Light backgrounds
  02 — Full Color / Dark backgrounds
  03 — Mono Navy / Light backgrounds
  04 — White / Dark backgrounds
  05 — Mono Black / Light backgrounds

  HORIZONTAL LOCKUP
  06 — Full Color / Light backgrounds
  07 — Full Color / Dark backgrounds
  08 — Mono Navy / Light backgrounds
  09 — White / Dark backgrounds
  10 — Mono Black / Light backgrounds

  ICON ONLY
  11 — Full Color / Light backgrounds
  12 — Full Color / Dark backgrounds
  13 — Mono Navy / Light backgrounds
  14 — White / Dark backgrounds
  15 — Mono Black / Light backgrounds

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

USAGE NOTES

  All files use transparent backgrounds.

  Treatments numbered 02, 04, 07, 09, 12, and 14 are
  designed for placement on dark (navy) backgrounds.
  These files contain white or light-colored artwork
  and will appear faint or invisible when viewed
  against a white background — this is correct behavior.

  For general use on light backgrounds, use treatments
  01, 03, 05, 06, 08, 10, 11, 13, or 15.

  RECOMMENDED FORMATS BY USE CASE:
  — Website / digital:     SVG (02_SVG)
  — Presentations / docs:  PNG (03_PNG)
  — Print / vendor use:    PDF (04_PDF)
  — Future edits:          AI  (01_AI)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

BRAND COLORS

  Navy   #475569
  Teal   #00BFA5
  Gold   #FBBF24
  Blue   #2563EB

TYPOGRAPHY

  Wordmark:  Lora (serif)
  UI / Body: DM Sans (sans-serif)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Questions? Contact HyperBrand Creative at hyperbrand.ai
